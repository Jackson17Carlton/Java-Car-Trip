
public class Auto 
{
	
	private String autoDescription;
	private int xCoor = 0;
	private int yCoor = 0;
	private GasTank tank;
	private Engine block;
	
	public Auto(String descrip, int maxFuel, Engine block)
	{
		if(descrip.length() <= 0)
		{
			this.autoDescription = "Generic engine";
		}
		else
		{
			this.autoDescription = descrip;
		}
		if (block == null)
		{
			this.block = new Engine("", 0, 0);
		}
		else
		{
			this.block = block;
		}
		
		this.tank = new GasTank(maxFuel);
	}
	
	public String getDescription()
	{
		String description = this.autoDescription + " (engine: " + block.getDescription() + "), fuel: " +
				tank.getLevel() + "/" + tank.getCapacity() + ", location: " + "(" + this.xCoor 
				+ "," + this.yCoor + ")";
		return description;
	}
	public int getX()
	{
		return this.xCoor;
	}
	public int getY()
	{
		return this.yCoor;
	}
	public double getFuelLevel()
	{
		return this.tank.getLevel();
	}
	public int getMPG()
	{
		return block.getMpg();
	}
	public void fillUp()
	{
		this.tank.setLevel(this.tank.getCapacity());
	}
	public int getMaxSpeed()
	{
		return block.getMaxspeed();
	}
	public double drive(int distance, double xRatio, double yRatio)
	{
		double carDist = this.getMPG() * this.getFuelLevel();
		double slope = Math.abs(yRatio/xRatio);
		double xDistance = 0;
		double yDistance = 0;
		if((int) distance > carDist)
		{
			xDistance = carDist * (Math.sqrt(1/(1 + Math.pow(slope, 2))));
			yDistance = slope * xDistance;
			if (xRatio <= 0)
			{
				this.xCoor -= xDistance;
			}
			else
			{
				this.xCoor += xDistance;
			}
			if (yRatio <= 0)
			{
				this.yCoor -= yDistance;
			}
			else
			{
				this.yCoor += yDistance;
			}
			System.out.println("Ran out of gas after driving " + carDist + " miles");
			this.tank.setLevel(0);
			return carDist;
		}
		else
		{
			double sub = carDist - distance;
			xDistance = distance * (Math.sqrt(1/(1 + Math.pow(slope, 2))));
			yDistance = slope * xDistance;
			if (xRatio <= 0)
			{
				this.xCoor -=  xDistance;
			}
			else
			{
				this.xCoor +=  xDistance;
			}
			if (yRatio <= 0)
			{
				this.yCoor -=  yDistance;
			}
			else
			{
				this.yCoor +=  yDistance;
			}
			this.tank.setLevel(sub/this.getMPG());
			return distance;
		}
	}
 
}
