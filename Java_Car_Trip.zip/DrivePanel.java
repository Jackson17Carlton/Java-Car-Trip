//Jackson Carlton 010856000 jlcarlto@uark.edu
//DrivePanel: Uses start and end coordinate arrays to trace movement of Auto after driving
//09/30/2019

import java.awt.Graphics;
import javax.swing.JPanel;
public class DrivePanel extends JPanel
{
	private int [] startX = new int[50];
	private int [] startY = new int[50];
	private int [] endX = new int[50];
	private int [] endY = new int[50];
	private int legs = 0;
	public DrivePanel(int [] begX, int [] begY, int [] finX, int [] finY, int legs)
	{
		this.legs = legs;
		for (int i = 0; i < legs; ++i)
		{
			this.startX[i] = begX[i];
			this.startY[i] = begY[i];
			this.endX[i] = finX[i];
			this.endY[i] = finY[i];
		}
	}
	public void paintComponent(Graphics leg)
	{
		super.paintComponent(leg);
		leg.translate(0, getHeight());
		for (int i = 0; i < legs; ++i)
		{
			leg.drawLine(startX[i], -(startY[i]), endX[i], -(endY[i]));
			String pos = "(" + endX[i] + ", " + endY[i] + ")";
			leg.drawString(pos, endX[i] + 5, -(endY[i]) + 5);
		}
		
		
	}
}

