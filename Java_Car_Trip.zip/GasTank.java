
public class GasTank {
	
	private int capacity;
	private double currLevel;
	
	public GasTank(int capacity)
	{
		if(capacity <= 0)
		{
			this.capacity = 0;
		}
		else
		{
			this.capacity = capacity;
			this.currLevel = 0;
		}
	}
	
	public int getCapacity()
	{
		return this.capacity;
	}
	
	public double getLevel()
	{
		double lev = this.currLevel;
		lev = Double.parseDouble(String.format("%.2f", lev));
		return lev;
	}

	public void setLevel(double levelIn)
	{
		if(levelIn <= 0)
		{
			this.currLevel = 0;
		}
		else if(levelIn > this.capacity)
		{
			this.currLevel = capacity;
		}
		else
		{
			this.currLevel = levelIn;
		}
		
	}
}
