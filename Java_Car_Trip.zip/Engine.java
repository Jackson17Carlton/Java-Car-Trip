
public class Engine {
	
	private String description;
	private int mpg;
	private int maxSpeed;
	
	public Engine(String desc, int mpGal, int max)
	{
		if(desc.length() <= 0)
		{
			this.description = "Generic engine";
		}
		else
		{
			this.description = desc;
		}
		if(mpGal <= 0)
		{
			this.mpg = 0;
		}
		else 
		{
			this.mpg = mpGal;
		}
		if(max <= 0)
		{
			this.maxSpeed = 0;
		}
		else
		{
			this.maxSpeed = max;
		}
	}
	
	public String getDescription()
	{
		String Description = this.description + " (MPG: " + this.mpg + ", Max Speed: " + this.maxSpeed + ")";
		return Description;
	}
	
	public int getMpg()
	{
		return this.mpg;
	}
	
	public int getMaxspeed()
	{
		return this.maxSpeed;
	}
}
