//Jackson Carlton 010856000 jlcarlto@uark.edu
//Assignment 3: Traces car trip from Auto class
//09/30/2019

import javax.swing.JOptionPane;
import javax.swing.JFrame;

public class Assignment3 {
	public static void main(String args[])
	{	
		//User input
		String autoDescription = JOptionPane.showInputDialog("Enter an auto description: ");
		
		//Fuel level exception handling
		int capacity = 0;
		try
		{
			capacity = Integer.parseInt(JOptionPane.showInputDialog("Enter a fuel tank capacity: "));
		}
		
		catch (NumberFormatException exception)
		{
			JOptionPane.showMessageDialog(null, "Invalid data entered. Exiting.");
			System.exit(0);
		}
		
		while (capacity < 1)
		{
			capacity = Integer.parseInt(JOptionPane.showInputDialog("Enter a positive value for " + 
																		  "fuel tank capacity: "));
		}
		
		String engineDescription = JOptionPane.showInputDialog("Enter an engine description: ");
		
		//MPG exception handling
		int mpg = 0;
		try
		{
			mpg = Integer.parseInt(JOptionPane.showInputDialog("Enter an engine MPG: "));
		}
		
		catch (NumberFormatException exception)
		{
			JOptionPane.showMessageDialog(null, "Invalid data entered. Exiting.");
			System.exit(0);
		}
		
		while (mpg < 1)
		{
			mpg = Integer.parseInt(JOptionPane.showInputDialog("Enter a positive value for mpg: ")); 
															
		}
		
		//Max speed exception handling
		int max = 0;
		try
		{
			max = Integer.parseInt(JOptionPane.showInputDialog("Enter a maximum speed: "));
		}
		
		catch (NumberFormatException exception)
		{
			JOptionPane.showMessageDialog(null, "Invalid data entered. Exiting.");
			System.exit(0);
		}
		
		while (max < 1)
		{
			max = Integer.parseInt(JOptionPane.showInputDialog("Enter a positive value for" + 
																	"max speed: "));
		}
		
		//Object initialization
		Engine block = new Engine(engineDescription, mpg, max);
		Auto car = new Auto(autoDescription, capacity, block);
		
		//Car dialog box
		String message = "Here are the details of your car: " + "\n" + car.getDescription();
		JOptionPane.showMessageDialog(null, message);
		
		//Get trip details
		int legs = 0; //iterating variable
		int ARRAY_SIZE = 50;
		int [] distances = new int[ARRAY_SIZE]; //holds Total distances
		double [] xLegs = new double[ARRAY_SIZE]; //holds xDistances
		double [] yLegs = new double[ARRAY_SIZE]; //holds yDistances
		
		try
		{
			legs = Integer.parseInt(JOptionPane.showInputDialog("Enter number of trip legs: "));
		}
		
		catch (NumberFormatException exception)
		{
			JOptionPane.showMessageDialog(null, "Invalid data entered. Exiting.");
			System.exit(0);
		}
		
		while (legs < 1)
		{
			legs = Integer.parseInt(JOptionPane.showInputDialog("Enter a positive value for" + 
																	"trip legs: "));
		}
		
		for(int i = 0; i < legs; ++i)
		{
			try
			{
				distances[i] = Integer.parseInt(JOptionPane.showInputDialog("Enter distance for leg " + 
																				(i + 1) + ": "));
			}
			
			catch (NumberFormatException exception)
			{
				JOptionPane.showMessageDialog(null, "Invalid data entered. Exiting.");
				System.exit(0);
			}
			
			while (distances[i] < 1) 
			{
				distances[i] = Integer.parseInt(JOptionPane.showInputDialog("Enter positive distance for " +
																		"leg: "));
			}
			
			
			try
			{
				xLegs[i] = Double.parseDouble(JOptionPane.showInputDialog("Enter x ratio for leg " +
																			(i + 1) + ": "));
			}
			
			catch (NumberFormatException exception)
			{
				JOptionPane.showMessageDialog(null, "Invalid data entered. Exiting.");
				System.exit(0);
			}
			
			try
			{
				yLegs[i] = Double.parseDouble(JOptionPane.showInputDialog("Enter y ratio for leg " +
																			(i + 1) + ": "));
			}
			
			catch (NumberFormatException exception)
			{
				JOptionPane.showMessageDialog(null, "Invalid data entered. Exiting.");
				System.exit(0);
			}
			
			
		}
		
		//Getting car coordinates before and after driving
		int [] startX = new int[ARRAY_SIZE];
		int [] startY = new int[ARRAY_SIZE];
		int [] endX = new int[ARRAY_SIZE];
		int [] endY = new int[ARRAY_SIZE];
		car.fillUp();
		for (int i = 0; i < legs; ++i)
		{
			startX[i] = car.getX();
			startY[i] = car.getY();
			car.drive(distances[i], xLegs[i], yLegs[i]);
			endX[i] = car.getX();
			endY[i] = car.getY();
		}
		
		DrivePanel trip = new DrivePanel(startX, startY, endX, endY, legs);
		JFrame map = new JFrame();
		map.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		map.add(trip);
		map.setSize(600,600);
		map.setVisible(true);
	}
}